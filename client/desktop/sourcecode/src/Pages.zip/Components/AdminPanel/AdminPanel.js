import { Divider, Typography } from '@mui/material';
import React, {useState} from 'react';
// import './AdminPanel.css';

const AdminPanel = () => {
    return (
        <div style={{width: '20vw', minHeight: '103.2%',backgroundColor: '#308695'}}>
            <Typography style={{paddingTop: '1vw', fontSize: '1.5vw', fontWeight: '700'}}>Admin Panel</Typography>
            <Divider style={{width: '15vw', margin: 'auto'}}/>
        </div>
    );
}

export default AdminPanel;