import React, {useState} from 'react';
import AdminPanel from '../Components/AdminPanel/AdminPanel.js';
import './Homepage.css';
import Button from '@mui/material/Button';

const Homepage = ({checkSession}) => {
    return (
        <div style={{display: 'flex', flexDirection: 'row'}}>
            <div>
                <AdminPanel />
            </div>
            <div style={{width: '80vw', minHeight: '48vw', position: 'relative'}}>
                <Button variant="contained" style={{marginTop: '1vw', position: 'absolute',right: '5vw', backgroundColor: '#308695'}} onClick={() => {localStorage.removeItem('token'); checkSession()}}>Log Out</Button>
            </div>
        </div>
    );
}

export default Homepage;